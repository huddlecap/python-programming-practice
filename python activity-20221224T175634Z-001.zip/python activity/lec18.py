number1 = 123
print(number1)
name = 'Naman'
print(name)
_trial = 'username'
print(_trial)
who_are_you = 'i am Naman'
print(who_are_you)