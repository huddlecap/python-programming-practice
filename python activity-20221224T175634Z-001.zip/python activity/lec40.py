name= "himan"
name += "shu"
print(name)
age=23
age-=1
print(age)