# check empty or not
# important
name= input("Enter your name: ")
if name:
    print(f"your name is {name}")
else:
    print("You didn't write anything")