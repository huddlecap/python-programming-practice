# user input
# input function
name = input("Whats your name?")
print("My name is-" + name )
location = input("where dou you live?")
print("I live in " + location )
work = input("What do you do?")
print("I'm doing " + work)
age = input("Whats your age?")
print("My age is-" + age)