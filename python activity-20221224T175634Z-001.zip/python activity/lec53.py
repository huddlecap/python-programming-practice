# loops
# while, for loop
# print("Hello world") # 10 times
i=1
while i<=10:
    print(f"Hello World{i}")
    i=i+1