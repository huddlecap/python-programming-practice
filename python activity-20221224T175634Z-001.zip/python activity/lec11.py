# this is a comment 
print("Hello World!")
print('Naman Kumar') #its my name 
print('12214944') #its my registration number
print('KOC09-27') # its my section & roll number
'''I am learning python coding langaunge from CipherSchools'''