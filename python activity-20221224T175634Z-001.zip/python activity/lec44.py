age= input("Enter your age: ")
age=int(age)
if age>=14:
    print("line a")
    print("You are above")
else:
    print("Sorry you can't play")