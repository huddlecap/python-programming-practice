# print("Himanshu"[-1::-1])
print("Naman"[::-1]) # trick