name, rollno=input("Enter your name and rollno ").split()
print(name)  
print(rollno) 

name, rollno=input("Enter your name and rollno ").split(",")
print(name)  
print(rollno) 