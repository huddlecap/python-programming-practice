a= (input("enter 1st no :")) #5
b= (input("enter 2nd no :")) #4
c= (input("enter 3rd no :")) #3

print(f"average of above three no.s: {(int(a)+int(b)+int(c))/3}") #(5+4+3)/3= 4.0