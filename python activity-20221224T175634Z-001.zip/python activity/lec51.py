name = "Naman"
# in keyword
# if with in
if 'N' in "Naman":
    print("N is present in name")
else:
    print("not present")
    